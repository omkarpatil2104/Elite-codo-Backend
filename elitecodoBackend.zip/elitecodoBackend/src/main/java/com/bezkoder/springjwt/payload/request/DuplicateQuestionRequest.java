package com.bezkoder.springjwt.payload.request;

import lombok.Data;

@Data
public class DuplicateQuestionRequest {
    private String question;

}
