package com.bezkoder.springjwt.payload.response;

public interface TeacherIdNameProjection {
    Long getId();
    String getName();
}
