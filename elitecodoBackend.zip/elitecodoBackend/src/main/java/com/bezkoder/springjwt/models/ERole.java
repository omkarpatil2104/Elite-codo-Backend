package com.bezkoder.springjwt.models;

public enum ERole {

    ROLE_SUPER_ADMIN,
    ROLE_ADMIN,
    ROLE_TEACHER,
    ROLE_STUDENT,
    ROLE_PARENT,
    ROLE_INSTITUTE

}
