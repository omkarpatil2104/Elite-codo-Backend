package com.bezkoder.springjwt.payload.request;

import com.bezkoder.springjwt.models.ChapterMaster;
import com.bezkoder.springjwt.models.QuestionMaster;
import com.bezkoder.springjwt.models.TopicMaster;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TestRequestSetWise {
    private Integer testId;

    private String testName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private Date testDate;

    //    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm")
    private LocalTime startTime;

    //    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm")
    private LocalTime endTime;

    private Double marks;

    private Integer entranceExamId;

    public Set<Integer> standardId;

    private Set<Integer> subjectId;

    private Set<Integer> chapterMasters;
    private Set<Integer> topicMasters;

    private List<ExamSetRequest> examSetRequests;

    private Long createdBy;

    private Date createdDate;

    private String status;

    private String typeOfTest;

    public String testMode;


}
